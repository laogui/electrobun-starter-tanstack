# 标题整理

Command-only plugin. Two files, no build, no Node/Bun/Electrobun imports.

The handler reads the frozen selection through `ctx.content.readSelection`, then submits title-only `content.applyBatch` operations. It does not invent `instanceId` or import host modules. Undo and persistence stay on the host.
